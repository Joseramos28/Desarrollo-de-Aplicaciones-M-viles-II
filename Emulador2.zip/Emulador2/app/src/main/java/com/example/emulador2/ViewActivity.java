package com.example.emulador2;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewActivity extends AppCompatActivity {


    Button play1,play2, play3, play4, play5;

    MediaPlayer mp1, mp2, mp3, mp4, mp5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view);


        play1 = (Button)findViewById(R.id.play1);
        play2 = (Button)findViewById(R.id.play2);
        play3 = (Button)findViewById(R.id.play3);
        play4 = (Button)findViewById(R.id.play4);
        play5 = (Button)findViewById(R.id.play5);


        mp1 = MediaPlayer.create(this,R.raw.whistle);
        mp2 = MediaPlayer.create(this,R.raw.tonomensaje);
        mp3 = MediaPlayer.create(this,R.raw.pacman);
        mp4 = MediaPlayer.create(this,R.raw.mariobros);
        mp5 = MediaPlayer.create(this,R.raw.iphone);

        play1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp1.isPlaying()){
                    mp1.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp1.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp2.isPlaying()){
                    mp2.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp2.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp3.isPlaying()){
                    mp3.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp3.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp4.isPlaying()){
                    mp4.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp4.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp5.isPlaying()){
                    mp5.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp5.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });





    }
}