package com.example.emulador;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Bloque 1
        WebView view = (WebView) findViewById(R.id.WebView1);
        WebSettings webSettings = view.getSettings();
        webSettings.setJavaScriptEnabled(true);
        view.loadUrl("https://www.sonidosmp3gratis.com/");

        //Bloque 2
        view.setWebViewClient( new WebViewClient(){
          public boolean shouldOverrideUrlLoading(WebView view, String url){
              view.loadUrl(url);
              return false;
          }

        });
    }
}